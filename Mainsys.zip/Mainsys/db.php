<?php
session_start();

$email = "";
$password = "";
$confirmpassword = "";
$firstname = "";
$middle = "";
$lastname = "";
$age = "";
$idnumber = "";
$yearlevel = "";
$gender = "";
$contact = "";
$address = "";
$errors = array(); 

$db = mysqli_connect('localhost', 'root', '', 'davedb');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reg_user'])) {

  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  $confirmpassword = mysqli_real_escape_string($db, $_POST['confirmpassword']);
  $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
  $middle = mysqli_real_escape_string($db, $_POST['middle']);
  $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
  $age = mysqli_real_escape_string($db, $_POST['age']);
  $idnumber = mysqli_real_escape_string($db, $_POST['idnumber']);
  $yearlevel = mysqli_real_escape_string($db, $_POST['yearlevel']);
  $gender = mysqli_real_escape_string($db, $_POST['gender']);
  $course = mysqli_real_escape_string($db, $_POST['course']);
  $contact = mysqli_real_escape_string($db, $_POST['contact']);
  $address = mysqli_real_escape_string($db, $_POST['address']);

  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $confirmpassword) {
	array_push($errors, "Password does not match");
  }

  $user_check_query = "SELECT * FROM account WHERE email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['email'] === $email)
      {
        array_push($errors, "Email already exists");
      } 
  }

  if (count($errors) == 0) {
  	$Pass_password = ($password);

  	$query = "INSERT INTO account (email, password, firstname, lastname, age, contact, idnumber, address, gender, yearlevel, middle, course) 
          VALUES('$email', '$Pass_password', '$firstname', '$lastname', '$age', '$contact', '$idnumber', '$address', '$gender', '$yearlevel', '$middle', '$course')";
  	mysqli_query($db, $query);
  	$_SESSION['email'] = $email;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}

// IMONG LOGIN NI
if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    if ($email === 'admin' && $password === 'admin') {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in as admin";
      header('location: adminsearch.php');
    } else {
      $password = ($password);
      $query = "SELECT * FROM account WHERE email ='$email' AND password='$password'";
      $results = mysqli_query($db, $query);
      if (mysqli_num_rows($results) == 1) {
        $_SESSION['email'] = $email;
        $_SESSION['success'] = "You are now logged in";
        header('location: student.php');
      } else {
        array_push($errors, "Wrong username/password combination");
      }
    }
  }
}

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
}

// IMONG SIT IN

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sit_in'])) {
    $id_number = mysqli_real_escape_string($db, $_POST['id_number']);
    $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
    $yearlevel = mysqli_real_escape_string($db, $_POST['yearlevel']);
    $course = mysqli_real_escape_string($db, $_POST['course']);
    $purpose = mysqli_real_escape_string($db, $_POST['purpose']);
    $lab_room = mysqli_real_escape_string($db, $_POST['lab_room']);
  
    $sql = "INSERT INTO sitinsession (firstname, lastname, year, course, id_number, purpose, lab_room, sit_in_time)
            VALUES ('$firstname', '$lastname', '$yearlevel', '$course', '$id_number','$purpose', '$lab_room', NOW())";

    if (mysqli_query($db, $sql)) {
        echo "Sit-in record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

// IMONG END SESSION

function endSession($id, $db) {
    $sql_fetch_session = "SELECT * FROM sitinsession WHERE id = '$id'";
    $result_fetch_session = mysqli_query($db, $sql_fetch_session);

    if ($result_fetch_session && mysqli_num_rows($result_fetch_session) > 0) {
        $session_data = mysqli_fetch_assoc($result_fetch_session);

        $sql_insert_ended_session = "INSERT INTO endedsessions (id, firstname, lastname, id_number, course, year, lab_room, purpose, sit_in_time, sit_out_time) 
            VALUES (NULL, '{$session_data['firstname']}', '{$session_data['lastname']}', '{$session_data['id_number']}', '{$session_data['course']}', '{$session_data['year']}', '{$session_data['lab_room']}', '{$session_data['purpose']}', '{$session_data['sit_in_time']}', NOW())";
        mysqli_query($db, $sql_insert_ended_session);

        $sql_delete_session = "DELETE FROM sitinsession WHERE id = '$id'";
        mysqli_query($db, $sql_delete_session);

        $sql_update_remaining = "UPDATE account SET remaining = CASE WHEN remaining > 0 THEN remaining - 1 ELSE 0 END WHERE idnumber = '{$session_data['id_number']}'";
        mysqli_query($db, $sql_update_remaining);

        return array('status' => 'success', 'message' => 'Session ended successfully.');
    } else {
        return array('status' => 'error', 'message' => 'Session not found.');
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['end_session'])) {
    $session_id = mysqli_real_escape_string($db, $_POST['session_id']);
    $response = endSession($session_id, $db);
    echo json_encode($response);
    exit();
}

// =================================== RESET PASSWORD ADMIN / SESSION ========================================

if (isset($_POST['reset_session'])) {
  $idnumber = $_POST['idnumber'];
  $sql = "UPDATE account SET remaining = 30 WHERE idnumber = '$idnumber'";
  if (mysqli_query($db, $sql)) {
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($db);
  }
}


if (isset($_POST['admin_edit_student'])) {
  $id_number = mysqli_real_escape_string($db, $_POST['id_number']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  $query = "UPDATE account SET password = '$password' WHERE idnumber = '$id_number'";

  if (mysqli_query($db, $query)) {

  } else {

  }
}
// ANNOUNCEMENT//
if (isset($_POST['post_announcement'])) {
  $announcement = mysqli_real_escape_string($db, $_POST['announcement']);
  $query = "INSERT INTO announcement (ann_notes, ann_date) VALUES ('$announcement', now())";

  mysqli_query($db, $query);

  header("Location: postannounce.php");
  exit();

}

// FEEDBACK//
if (isset($_POST['my_feedback'])) {
  $feedback = mysqli_real_escape_string($db, $_POST['feedback']);
  $query = "INSERT INTO feedback (feedback_notes, feedback_date) VALUES ('$feedback', now())";

  mysqli_query($db, $query);

  header("Location: feedback.php");
  exit();

}

?>