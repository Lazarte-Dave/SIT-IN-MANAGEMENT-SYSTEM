-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2024 at 05:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `davedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middle` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `age` int(200) NOT NULL,
  `idnumber` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `yearlevel` int(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'student',
  `course` varchar(200) NOT NULL,
  `remaining` int(30) NOT NULL DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`user_id`, `firstname`, `middle`, `lastname`, `age`, `idnumber`, `password`, `gender`, `yearlevel`, `contact`, `email`, `address`, `role`, `course`, `remaining`) VALUES
(1, 'Ronald ', 'Gabato', 'Lazarte', 21, 21540943, 'user', 'Male', 4, '0909090909', 'ronron@gmail.com', 'H.labra', 'student', 'BSIT', 30),
(2, 'Ivan', 'Kerzen', 'Booc', 22, 21540944, 'user', 'Male', 3, '01010101010', 'booc@gmail.com', 'Street dan', 'student', 'BSIT', 30);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `announcement_id` int(11) NOT NULL,
  `ann_notes` text DEFAULT NULL,
  `ann_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`announcement_id`, `ann_notes`, `ann_date`) VALUES
(1, 'TO DAY IS ANOTHER DAY', '2024-05-11 14:19:52'),
(2, 'PANOD NAMO SA SCHOOL STUDENTS', '2024-05-11 14:23:20');

-- --------------------------------------------------------

--
-- Table structure for table `endedsessions`
--

CREATE TABLE `endedsessions` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `lab_room` varchar(50) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `sit_in_time` datetime NOT NULL,
  `sit_out_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `endedsessions`
--

INSERT INTO `endedsessions` (`id`, `firstname`, `lastname`, `id_number`, `course`, `year`, `lab_room`, `purpose`, `sit_in_time`, `sit_out_time`) VALUES
(39, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'C#', '2024-04-21 11:52:16', '2024-04-21 12:14:12'),
(40, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:52:53', '2024-04-21 12:15:51'),
(41, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:58:15', '2024-04-21 12:15:54'),
(42, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:58:50', '2024-04-21 12:22:07'),
(43, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Python', '2024-04-21 12:47:31', '2024-04-21 12:47:37'),
(44, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '524', 'C#', '2024-04-21 12:48:05', '2024-04-21 12:48:13'),
(45, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'C#', '2024-04-21 12:50:14', '2024-04-21 12:50:18'),
(46, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Python', '2024-04-21 12:50:28', '2024-04-21 12:51:58'),
(47, 'ANGELA', 'ALBA', '21457033', 'BSCS', '3', '525', 'Java', '2024-04-21 12:51:31', '2024-04-21 12:51:59'),
(48, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'C#', '2024-04-21 12:51:38', '2024-04-21 12:51:59'),
(49, 'ANGELA', 'ALBA', '21457033', 'BSCS', '3', '525', 'C#', '2024-04-21 12:51:47', '2024-04-21 12:52:00'),
(50, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '526', 'Java', '2024-04-21 12:51:53', '2024-04-21 12:52:01'),
(51, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Java', '2024-04-21 14:01:19', '2024-04-21 14:01:23'),
(52, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'Java', '2024-04-21 14:27:18', '2024-04-21 14:27:28'),
(53, 'BRANDON', 'ALCARMEN', '21457035', 'BSCS', '3', '525', 'Java', '2024-04-21 15:55:44', '2024-04-21 15:56:01'),
(54, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'Java', '2024-05-11 13:15:22', '2024-05-11 13:15:31'),
(55, 'ALBA', 'ANGELA', '21457033', 'BSCS', '3', '', '', '2024-05-11 13:12:41', '2024-05-11 13:15:47');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `feedback_notes` text DEFAULT NULL,
  `feedback_date` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `feedback_notes`, `feedback_date`, `user_id`) VALUES
(4, 'shample', '2024-05-11 23:36:44', 2),
(5, 'dasdasdasdas', '2024-05-11 23:37:49', 2);

-- --------------------------------------------------------

--
-- Table structure for table `sitinsession`
--

CREATE TABLE `sitinsession` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `lab_room` varchar(255) DEFAULT NULL,
  `sit_in_time` datetime DEFAULT NULL,
  `sit_out_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sitinsession`
--

INSERT INTO `sitinsession` (`id`, `firstname`, `lastname`, `year`, `course`, `id_number`, `purpose`, `lab_room`, `sit_in_time`, `sit_out_time`) VALUES
(103, 'ALBA', 'ANGELA', 3, 'BSCS', '21457033', '', '', '2024-05-11 13:13:49', NULL),
(104, 'ALBA', 'ANGELA', 3, 'BSCS', '21457033', '', '', '2024-05-11 13:13:54', NULL),
(105, 'ALBA', 'ANGELA', 3, 'BSCS', '21457033', '', '', '2024-05-11 13:14:28', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`user_id`) USING BTREE,
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `endedsessions`
--
ALTER TABLE `endedsessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `fk_feedback_user_id` (`user_id`);

--
-- Indexes for table `sitinsession`
--
ALTER TABLE `sitinsession`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `endedsessions`
--
ALTER TABLE `endedsessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sitinsession`
--
ALTER TABLE `sitinsession`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_feedback_user_id` FOREIGN KEY (`user_id`) REFERENCES `account` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
